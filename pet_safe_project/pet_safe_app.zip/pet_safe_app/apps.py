from django.apps import AppConfig


class PetSafeAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'pet_safe_app'
